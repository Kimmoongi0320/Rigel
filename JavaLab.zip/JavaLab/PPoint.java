package kr.ac.kookmin.cs;
public class PPoint {
    int xA;
    int yA;
    /**
      set up x and y
    */	
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    /**
      get a
    */
    public int getX() {
        return xA;
    }
     /**
      get b
    */
    public int getY() {
        return yA;
    }
}
